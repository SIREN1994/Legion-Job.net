
<?php $__env->startSection('content'); ?>

<div class="mt-15"></div> <!-- Adding 15 pixels gap -->

<div class="flex justify-center items-center">

    <div class="max-w-md mx-auto bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        
        <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
               <strong class="font-bold">Error!</strong>
               <span class="block sm:inline"><?php echo e(session('error')); ?></span>
        </div>
       <?php endif; ?>

        <!-- Check if there is a success message in the session -->
        <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <strong class="font-bold">Success!</strong>
            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
        </div>
       <?php endif; ?>
       
        <h1 class="text-2xl font-bold mb-4">Profile Information</h1>

        <!-- Profile Information Form -->
        <div class="flex justify-center mb-4">
            <img src="<?php echo e($pp); ?>" alt="" class="w-32 h-32 object-cover rounded-full border-4 border-white">
            <form action="/uploadpfp" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="ml-4">
                    <label for="description" class="block text-sm font-medium text-gray-600">Upload Profile Picture</label>
                    <input type="file" id="profilepic" name="profilepic" class="mt-1 p-2 border rounded-md focus:outline-none focus:border-blue-500">
                </div>
                <button type="submit" class="mt-4 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 focus:outline-none">Upload Picture</button>
            </form>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-bold mb-2" for="name">Name:</label>
            <p class="text-gray-900"><?php echo e($user); ?></p>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-bold mb-2" for="id">ID:</label>
            <p class="text-gray-900"><?php echo e($id); ?></p>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-bold mb-2" for="cv">Current CV:</label>
            <?php if($cv): ?>
            <p><?php echo e(pathinfo($cv, PATHINFO_FILENAME)); ?></p>
            <?php else: ?>
            <p class="text-red-500">No CV uploaded</p>
            <?php endif; ?>
        </div>

        <div class="mb-4">
            <form action="/updatecv" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label class="block text-gray-700 font-bold mb-2" for="resume">Upload a new CV:</label>
                    <input type="file" name="resume" accept=".pdf" class="appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 focus:outline-none focus:shadow-outline">Update CV</button>
            </form>
        </div>

        <div>
            <form action="/changepassword" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label class="block text-gray-700 font-bold mb-2" for="resume">Change Password</label>
                    <input type="text" placeholder="Enter Current Password" name="oldpass" class="appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline mb-5" >
                    <input type="text" placeholder="Enter New Password" name="newpass" class="appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 focus:outline-none focus:shadow-outline">Change Password</button>
            </form>
        </div>
    </div>
</div>

<div class="mt-15"></div> <!-- Adding 15 pixels gap -->

<div class="bg-white mx-auto p-6 rounded-lg shadow-lg ">
    <h2 class="text-xl font-bold mb-4 flex justify-center items-center">Applied Jobs</h2>
    <div class="overflow-x-auto flex justify-center items-center">
        <table class="table-auto border-collapse border border-gray-400 ">
            <thead>
                <tr>
                    <th class="border border-gray-400 px-4 py-2">Name</th>
                    <th class="border border-gray-400 px-4 py-2">User ID</th>
                    <th class="border border-gray-400 px-4 py-2">User Email</th>
                    <th class="border border-gray-400 px-4 py-2">Applied Job ID</th>
                    <th class="border border-gray-400 px-4 py-2">Job Title</th>
                    <th class="border border-gray-400 px-4 py-2">Company Name</th>
                    <th class="border border-gray-400 px-4 py-2">Applied Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border border-gray-400 px-4 py-2"><?php echo e($record->client_name); ?></td>
                    <td class="border border-gray-400 px-4 py-2"><?php echo e($record->client_id); ?></td>
                    <td class="border border-gray-400 px-4 py-2"><?php echo e($record->client_email); ?></td>
                    <td class="border border-gray-400 px-4 py-2"><?php echo e($record->job_id); ?></td>
                    <td class="border border-gray-400 px-4 py-2"><?php echo e($record->job_title); ?></td>
                    <td class="border border-gray-400 px-4 py-2"><?php echo e($record->company_name); ?></td>
                    <td class="border border-gray-400 px-4 py-2"><?php echo e($record->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\resources\views/User/profile.blade.php ENDPATH**/ ?>