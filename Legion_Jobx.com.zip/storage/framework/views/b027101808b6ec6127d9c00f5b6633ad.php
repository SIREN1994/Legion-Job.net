<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demo Website Features</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>

<body class="bg-white p-8">
    <div class="max-w-3xl mx-auto overflow-y-auto" style="max-height: 1200px;">
        <h1 class="text-4xl font-bold mb-8 text-center text-gray-800">In this demo website you will find web functions such as</h1>
        <div class="mb-8">
            <h2 class="text-2xl font-bold mb-4 text-gray-800">On the Users side</h2>
            <ul class="list-disc list-inside">
                <li>User registration and authentication functions</li>
                <li>Log in / log out functions</li>
                <li>Individual user profile creation and resume files uploading function</li>
                <li>Individual user profile updating and resume files updating</li>
                <li>Change password and forget password function</li>
                <li>Real-time email notifications (so register with real email to see)</li>
                <li>Search jobs by company name, location, and position filters</li>
                <li>User jobs applications history</li>
            </ul>
        </div>
        <div class="mb-8">
            <h2 class="text-2xl font-bold mb-4 text-gray-800">On the admin side</h2>
            <ul class="list-disc list-inside">
                <li>Add and remove jobs</li>
                <li>Edit and update existing job contents</li>
                <li>Check user job application and download their resumes</li>
                <li>Check overview Jobs, User limits, and user application history by filters</li>
            </ul>
        </div>
        <div class="text-center">
            <h2 class="text-4xl font-bold mb-4 text-gray-800">No premade templates and pre-existed codes are used to create this website</h1>
            <h2 class="text-4xl font-bold mb-4 text-gray-800">Every code is manually written, custom made, unique, and exclusive</h1>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\resources\views/pop_up.blade.php ENDPATH**/ ?>