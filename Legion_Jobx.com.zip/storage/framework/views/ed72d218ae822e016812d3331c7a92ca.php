
<?php $__env->startSection('content'); ?>

<form action="/xx" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div>
    <label for="title">Change The Title</label>
    <textarea name="title"><?php echo e($job->title); ?></textarea>
    </div>
    <br>
    <div>
    <!-- Add input field for uploading a new logo -->
    <label for="logo">Change Logo</label>
    <input type="file" name="logo">
    </div>
<br><br>
    <button name="getID" value="<?php echo e($job->job_id); ?>">CHANGE</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.adminpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\resources\views/Admin/testo1.blade.php ENDPATH**/ ?>