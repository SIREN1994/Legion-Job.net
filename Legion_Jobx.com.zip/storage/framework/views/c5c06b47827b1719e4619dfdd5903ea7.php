
<?php $__env->startSection('content'); ?>


<div class="flex flex-wrap justify-center">
    <!--This $jpbs data came from app service provider-->
    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white p-8 rounded shadow-md w-96 m-4">
        <img src="<?php echo e(asset($company->logo)); ?>" alt="<?php echo e($company->title); ?> Logo" class="w-full h-32 object-cover mb-4">

        <h2 class="text-xl font-semibold mb-2"><?php echo e($company->title); ?></h2>
        <h2 class="text-xl font-semibold mb-2">Hiring Company : <?php echo e($company->company); ?></h2>
        <p class="text-gray-500 mb-2"><?php echo e($company->tags); ?></p>
        <h2 class="text-xl font-semibold mb-2">Location: <?php echo e($company->location); ?></h2>
        <!--Edit -->
        <form action="/detailjob" method="GET">
            <?php echo csrf_field(); ?>
            <button type="submit" name="getID" value="<?php echo e($company->job_id); ?>" class="bg-blue-500 text-white p-2 rounded w-full hover:bg-blue-600 focus:outline-none">
                Apply Now
            </button> <br><br>       
        </form>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\resources\views/companies.blade.php ENDPATH**/ ?>