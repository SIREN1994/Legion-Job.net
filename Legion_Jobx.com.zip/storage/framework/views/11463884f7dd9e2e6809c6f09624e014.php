

<?php $__env->startSection('content'); ?>


<br>
<section class="bg-blue-500 text-white py-16">
    <div class="container mx-auto text-center">
        <h1 class="text-4xl font-extrabold mb-4">Find Your Dream Job</h1>
        <p class="text-lg mb-8">Explore thousands of job opportunities and take the next step in your career.</p>
        <div class="flex justify-center">
            <form action="/query1" method="GET" class="flex space-x-2">
                <?php echo csrf_field(); ?>
                <!-- Search Box for Position/Level -->
                <div>
                    <input type="text" name="position_level" placeholder="Position/Level" class="w-32 p-3 rounded-full text-black focus:outline-none focus:shadow-outline-blue">
                </div>   
                
                <!-- Radio Choice Drop-down for Classification -->
                <div class="relative">
                    <select class="appearance-none w-32 p-3 rounded-full text-black focus:outline-none focus:shadow-outline-blue" name="classification">
                        <option value="" >Any Classification</option>
                        <option value="Sale">Sales</option>
                        <option value="Marketing">Marketing</option>
                        <option value="Advertising">Advertising</option>
                        <option value="HR">HR</option>
                        <option value="Finance">Finance</option>
                        <option value="Logistic">Logistic</option>
                        <option value="IT">IT</option>
                        <option value="Audit">Audit</option>
                        <option value="Public Relation">Public Relation</option>
                        
                    </select>
                </div>

                <!-- Radio Choice Drop-down for Location -->
                <div class="relative">
                    <select class="appearance-none w-32 p-3 rounded-full text-black focus:outline-none focus:shadow-outline-blue" name="location">
                        <option value="" >Any City</option>
                        <option value="Japan">Japan</option>
                        <option value="Thailand">Thailand</option>
                        <option value="USA">USA</option>
                        <option value="Singapore">Singapore</option>
                    </select>
                </div>

                <!-- Seek Button (Rectangular) -->
                <button class="bg-yellow-500 text-blue-500 p-3 rounded hover:bg-yellow-600 hover:text-white focus:outline-none">
                    Seek
                </button>
            </form>
        </div>
    </div>
</section>

<?php if($jobs): ?>
    
<div class="flex flex-wrap justify-center">
    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white p-8 rounded shadow-md w-96 m-4">
        <img src="<?php echo e(asset($job->logo)); ?>" alt="<?php echo e($job->title); ?> Logo" class="w-full h-32 object-cover mb-4">
        <h2 class="text-xl font-semibold mb-2"><?php echo e($job->title); ?></h2>
        <h2 class="text-xl font-semibold mb-2">Hiring Company : <?php echo e($job->company); ?></h2>
        <p class="text-gray-500 mb-2"><?php echo e($job->tags); ?></p>
        <h2 class="text-xl font-semibold mb-2">Location: <?php echo e($job->location); ?></h2>
        <!--Edit -->
        <form action="/detailjob" method="GET">
            <?php echo csrf_field(); ?>
            <button type="submit" name="getID" value="<?php echo e($job->job_id); ?>" class="bg-blue-500 text-white p-2 rounded w-full hover:bg-blue-600 focus:outline-none">
                Apply Now
            </button> <br><br>       
        </form>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php else: ?>

    <div>No Jobs Found</div>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\resources\views/SearchResult.blade.php ENDPATH**/ ?>