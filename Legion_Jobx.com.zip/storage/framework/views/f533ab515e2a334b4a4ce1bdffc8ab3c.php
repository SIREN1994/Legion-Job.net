<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spicy HTML with CSS and JS</title>
    <style>
        h1 {
            font-size: 36px;
            font-weight: bold;
            color: #ff6347; /* Tomato color */
            text-align: center;
            text-transform: uppercase;
            margin-bottom: 20px;
            animation: colorChange 2s infinite alternate; /* Apply animation */
            position: absolute; /* Position the element absolutely */
        }

        p {
            font-size: 18px;
            color: #696969; /* Dim gray color */
            text-align: center;
            line-height: 1.5;
            background-color: #90ee90; /* Light green color */
            padding: 20px;
            border-radius: 10px; /* Rounded corners */
        }

        @keyframes colorChange {
            0% {
                color: #ff6347; /* Tomato color */
            }
            50% {
                color: #4169e1; /* Royal blue color */
            }
            100% {
                color: #ff6347; /* Tomato color */
            }
        }
    </style>
</head>
<body>
    <h1>Spicy HTML with CSS and JS</h1>
    <div class="green-box">
        <p>This HTML got some spicy CSS and JavaScript added to it. Isn't it fancy?</p>
    </div>

    <script>
        // JavaScript to manipulate the <h1> element
        document.addEventListener('DOMContentLoaded', function() {
            const h1 = document.querySelector('h1');
            setInterval(function() {
                // Randomize position within the window
                const newX = Math.random() * (window.innerWidth - h1.offsetWidth);
                const newY = Math.random() * (window.innerHeight - h1.offsetHeight);
                h1.style.left = newX + 'px';
                h1.style.top = newY + 'px';
            }, 2000); // Move the element every 2 seconds
        });
    </script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\resources\views/test.blade.php ENDPATH**/ ?>