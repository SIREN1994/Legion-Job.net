<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Tailwind Footer</title>
    
    <!-- Tailwind CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">

    <!-- Your page content goes here -->

    <footer class="bg-blue-500 text-white p-4 mt-8">
        <div class="container mx-auto flex items-center justify-center">
            <!-- "All reserved" text -->
            <p class="text-sm">&copy; 2024 LEGION Job net.com. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\laravel\resources\views/footer.blade.php ENDPATH**/ ?>