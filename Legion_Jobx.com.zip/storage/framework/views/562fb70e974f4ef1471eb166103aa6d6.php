<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Tailwind Header</title>
    
    <!-- Tailwind CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">

    <header class="bg-blue-500 p-4">
        <div class="container mx-auto flex justify-between items-center">
            <!-- Logo on the left -->
            <div class="flex items-center">
                <!-- Replace 'your-logo.png' with your actual logo file -->
                <img src="your-logo.png" alt="Logo" class="h-8 mr-2">
                <span class="text-white text-lg font-semibold">Your Logo</span>
            </div>

            <!-- Navigation tabs on the right -->
            <nav class="flex items-center space-x-4">
                <!-- Home tab with home icon -->
                <a href="#" class="text-white flex items-center">
                    <svg class="h-5 w-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 19l-7-7 1.414-1.414L12 16.172l5.586-5.586L19 12l-7 7z"></path>
                    </svg>
                    Home
                </a>

                <!-- About Us tab with about us icon -->
                <a href="#" class="text-white flex items-center">
                    <svg class="h-5 w-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 19l-7-7 1.414-1.414L12 16.172l5.586-5.586L19 12l-7 7z"></path>
                    </svg>
                    About Us
                </a>

                <!-- Login tab with login icon -->
                <a href="#" class="text-white flex items-center">
                    <svg class="h-5 w-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                    </svg>
                    Login
                </a>

                <!-- Search Box with Magnifying icon button -->
                <div class="relative">
                    <input type="text" placeholder="Search"
                        class="bg-white rounded-full px-4 py-2 focus:outline-none focus:shadow-outline-blue focus:border-blue-500">
                    <button type="button"
                        class="absolute right-0 top-0 mt-2 mr-3 focus:outline-none text-gray-600">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M21 21l-5-5m2-5c0-3.866-3.134-7-7-7s-7 3.134-7 7 3.134 7 7 7 7-3.134 7-7z"></path>
                        </svg>
                    </button>
                </div>
            </nav>
        </div>
    </header>

    <!-- Your page content goes here -->

</body>
</html>
<?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\laravel\resources\views/header.blade.php ENDPATH**/ ?>