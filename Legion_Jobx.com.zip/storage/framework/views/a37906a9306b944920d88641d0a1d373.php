

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(auth()->check()): ?>
            <h1>Welcome, <?php echo e(auth()->user()->name); ?></h1>
            <p>You are currently logged in.</p>
        <?php else: ?>
            <h1>Unauthenticated User</h1>
            <p>You are not logged in.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\resources\views/authtest.blade.php ENDPATH**/ ?>