
<?php $__env->startSection('content'); ?>

<div class="flex flex-wrap justify-center">

    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white p-8 rounded shadow-md w-96 m-4">
        <img src="<?php echo e(asset($job->logo)); ?>" alt="<?php echo e($job->title); ?> Logo" class="w-full h-32 object-cover mb-4">

        <h2 class="text-xl font-semibold mb-2"><?php echo e($job->title); ?></h2>
        <h2 class="text-xl font-semibold mb-2">Hiring Company : <?php echo e($job->company); ?></h2>
        <p class="text-gray-500 mb-2"><?php echo e($job->tags); ?></p>
        <h2 class="text-xl font-semibold mb-2">Location: <?php echo e($job->location); ?></h2>
        <!--Edit -->
        <form action="/jobs_edit" method="GET">
            <?php echo csrf_field(); ?>
            <button type="submit" name="getID" value="<?php echo e($job->job_id); ?>" class="bg-blue-500 text-white p-2 rounded w-full hover:bg-blue-600 focus:outline-none">
                Edit Job
            </button> <br><br>       
        </form>
      
        <!--delete -->
        <form action="/delete" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" name="getID" value="<?php echo e($job->job_id); ?>" class="bg-blue-500 text-white p-2 rounded w-full hover:bg-blue-600 focus:outline-none">
                Delete Job
            </button>
        </form>
    </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php echo e($jobs->links()); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.adminpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\resources\views/Admin/Edit_Jobs.blade.php ENDPATH**/ ?>