
<?php $__env->startSection('content'); ?>

<section x-data="{ backgroundImageIndex: 2 }" x-init="startBackgroundImageInterval()" class="hero-section bg-cover bg-center" :style="'background-image: url(\'/' + backgroundImageIndex + '.jpg\')';">
    <div class="container mx-auto text-center">
        <h1 class="text-4xl font-extrabold mb-4">Find Your Dream Job</h1>
        <p class="text-lg mb-8">Explore thousands of job opportunities and take the next step in your career.</p>
    </div> 
</section>

<script>
    function startBackgroundImageInterval() {
        setInterval(changeBackgroundImage, 2000);
    }

    function changeBackgroundImage() {
        const currentImageIndex = parseInt(document.querySelector('.hero-section').getAttribute('x-data').backgroundImageIndex);
        const nextImageIndex = currentImageIndex === 4 ? 1 : currentImageIndex + 1;
        document.querySelector('.hero-section').setAttribute('x-data', '{ backgroundImageIndex: ' + nextImageIndex + ' }');
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\resources\views/carousel.blade.php ENDPATH**/ ?>