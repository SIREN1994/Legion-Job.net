
<?php $__env->startSection('content'); ?>

<div class="text-center py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-4">Jobs Search By Category</h1>
</div>

<div class="flex flex-wrap justify-center">
    
    <!--This $jpbs data came from app service provider-->
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white p-8 rounded shadow-md w-96 m-4">
        <img src="<?php echo e(asset($category->logo)); ?>" alt="<?php echo e($category->title); ?> Logo" class="w-full h-32 object-cover mb-4">

        <h2 class="text-xl font-semibold mb-2"><?php echo e($category->title); ?></h2>
        <h2 class="text-xl font-semibold mb-2">Hiring Company : <?php echo e($category->company); ?></h2>
        <p class="text-gray-500 mb-2"><?php echo e($category->tags); ?></p>
        <h2 class="text-xl font-semibold mb-2">Location: <?php echo e($category->location); ?></h2>
        <!--Edit -->
        <form action="/detailjob" method="GET">
            <?php echo csrf_field(); ?>
            <button type="submit" name="getID" value="<?php echo e($category->job_id); ?>" class="bg-blue-500 text-white p-2 rounded w-full hover:bg-blue-600 focus:outline-none">
                Apply Now
            </button> <br><br>       
        </form>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\resources\views/category.blade.php ENDPATH**/ ?>