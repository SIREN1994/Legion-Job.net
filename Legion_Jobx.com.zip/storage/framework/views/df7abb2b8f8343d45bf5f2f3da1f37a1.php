

<?php $__env->startSection('content'); ?>

<!--Hero Section-->
<br>
<section class="bg-blue-500 text-white py-16">
    <div class="container mx-auto text-center">
        <h1 class="text-4xl font-extrabold mb-4">Find Your Dream Job</h1>
        <p class="text-lg mb-8">Explore thousands of job opportunities and take the next step in your career.</p>
        <div class="flex justify-center">
            <input type="text" placeholder="Enter your job title or keywords" class="w-64 p-2 rounded-l focus:outline-none focus:shadow-outline-blue">
            <button class="bg-yellow-500 text-blue-500 p-2 rounded-r hover:bg-yellow-600 hover:text-white focus:outline-none">
                Search
            </button>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\laravel\resources\views/home.blade.php ENDPATH**/ ?>