
<?php $__env->startSection('content'); ?>

<h1>This Is Where You Delete The Jobs</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.adminpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel Protocol\Legion_Jobs.com\resources\views/Admin/Delete_Jobs.blade.php ENDPATH**/ ?>