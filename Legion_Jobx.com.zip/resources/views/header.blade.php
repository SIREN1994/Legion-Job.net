
<?php
// Check if the user is authenticated
$user = auth()->user();

// If authenticated, use auth()->user() data
if ($user) {
    $userName = $user->name;
    $userId = $user->client_id;
} else {
    // If not authenticated, use session data (if it exists)
    $sessionUser = session()->get('user', null);

    // Check if session data exists and retrieve user name and ID
    if ($sessionUser) {
        $userName = $sessionUser['name'];
        $userId = $sessionUser['client_id'];
    } else {
        // Set default values or an empty state for non-authenticated users
        $userName = 'Guest';
        $userId = "00000";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
    <!-- Tailwind CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">

    <header class="bg-blue-500 p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="/">
            <!-- Logo on the left -->
            <div class="flex items-center">
                <!-- Replace 'your-logo.png' with your actual logo file -->
                    <img src="/Golden Legion.png" alt="Logo" class="h-20 w-15 mr-2">
                    <span class="text-white text-lg font-semibold">LEGION Jobs.net</span>               
            </div>
            </a>



            <!-- Navigation tabs on the right -->
            <nav class="flex items-center space-x-4">
                <!-- Home tab with home icon -->

                <!-- Search Companies -->
                
                <div x-data="{ dropdownOpen: false }" class="relative">
                    <div @click="dropdownOpen = !dropdownOpen" class="text-white flex items-center cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-6 h-6">
                            <path fill-rule="evenodd" d="M3 2.25a.75.75 0 0 0 0 1.5v16.5h-.75a.75.75 0 0 0 0 1.5H15v-18a.75.75 0 0 0 0-1.5H3ZM6.75 19.5v-2.25a.75.75 0 0 1 .75-.75h3a.75.75 0 0 1 .75.75v2.25a.75.75 0 0 1-.75.75h-3a.75.75 0 0 1-.75-.75ZM6 6.75A.75.75 0 0 1 6.75 6h.75a.75.75 0 0 1 0 1.5h-.75A.75.75 0 0 1 6 6.75ZM6.75 9a.75.75 0 0 0 0 1.5h.75a.75.75 0 0 0 0-1.5h-.75ZM6 12.75a.75.75 0 0 1 .75-.75h.75a.75.75 0 0 1 0 1.5h-.75a.75.75 0 0 1-.75-.75ZM10.5 6a.75.75 0 0 0 0 1.5h.75a.75.75 0 0 0 0-1.5h-.75Zm-.75 3.75A.75.75 0 0 1 10.5 9h.75a.75.75 0 0 1 0 1.5h-.75a.75.75 0 0 1-.75-.75ZM10.5 12a.75.75 0 0 0 0 1.5h.75a.75.75 0 0 0 0-1.5h-.75ZM16.5 6.75v15h5.25a.75.75 0 0 0 0-1.5H21v-12a.75.75 0 0 0 0-1.5h-4.5Zm1.5 4.5a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75h-.008a.75.75 0 0 1-.75-.75v-.008Zm.75 2.25a.75.75 0 0 0-.75.75v.008c0 .414.336.75.75.75h.008a.75.75 0 0 0 .75-.75v-.008a.75.75 0 0 0-.75-.75h-.008ZM18 17.25a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75h-.008a.75.75 0 0 1-.75-.75v-.008Z" clip-rule="evenodd" />
                        </svg>
                        All Companies
                    </div>
                    <div x-show="dropdownOpen" @click.away="dropdownOpen = false" class="dropdown1 absolute top-10 right-0 bg-white shadow-md rounded-md">
                        <ul>
                            @foreach ($companies as $company)
                                <li><a href="/company/{{$company->company}}" class="block px-4 py-2 hover:bg-gray-700 cursor-pointer">{{$company->company}}</a></li>   
                            @endforeach
                            
                        </ul>
                    </div>
                </div>



                 <!-- Search Category -->
                <div x-data="{ dropdownOpen: false }" class="relative">
                    <div class="text-white flex items-center cursor-pointer" @click="dropdownOpen = !dropdownOpen">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-6 h-6">
                            <path d="M7.5 3.375c0-1.036.84-1.875 1.875-1.875h.375a3.75 3.75 0 0 1 3.75 3.75v1.875C13.5 8.161 14.34 9 15.375 9h1.875A3.75 3.75 0 0 1 21 12.75v3.375C21 17.16 20.16 18 19.125 18h-9.75A1.875 1.875 0 0 1 7.5 16.125V3.375Z" />
                            <path d="M15 5.25a5.23 5.23 0 0 0-1.279-3.434 9.768 9.768 0 0 1 6.963 6.963A5.23 5.23 0 0 0 17.25 7.5h-1.875A.375.375 0 0 1 15 7.125V5.25ZM4.875 6H6v10.125A3.375 3.375 0 0 0 9.375 19.5H16.5v1.125c0 1.035-.84 1.875-1.875 1.875h-9.75A1.875 1.875 0 0 1 3 20.625V7.875C3 6.839 3.84 6 4.875 6Z" />
                        </svg>
                                            
                        Jobs Category
                    </div>                    
                    <div x-show="dropdownOpen" @click.away="dropdownOpen = false" class="dropdown1 absolute top-10 right-0 bg-white shadow-md rounded-md">
                        <ul>
                            @foreach ($categories as $category)
                                <li><a href="/category/{{$category->job_category}}" class="block px-4 py-2 hover:bg-gray-700 cursor-pointer">{{$category->job_category}}</a></li>   
                            @endforeach
                        </ul>
                    </div>
                </div>
                
                

                <!-- Login tab with login icon -->
                <a href="/form2" class="text-white flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-6 h-6">
                        <path fill-rule="evenodd" d="M7.5 6a4.5 4.5 0 1 1 9 0 4.5 4.5 0 0 1-9 0ZM3.751 20.105a8.25 8.25 0 0 1 16.498 0 .75.75 0 0 1-.437.695A18.683 18.683 0 0 1 12 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 0 1-.437-.695Z" clip-rule="evenodd" />
                      </svg>
                                           
                    Login
                </a>

                <!-- Register tab with icon -->
                <a href="/form" class="text-white flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-6 h-6">
                        <path fill-rule="evenodd" d="M7.502 6h7.128A3.375 3.375 0 0 1 18 9.375v9.375a3 3 0 0 0 3-3V6.108c0-1.505-1.125-2.811-2.664-2.94a48.972 48.972 0 0 0-.673-.05A3 3 0 0 0 15 1.5h-1.5a3 3 0 0 0-2.663 1.618c-.225.015-.45.032-.673.05C8.662 3.295 7.554 4.542 7.502 6ZM13.5 3A1.5 1.5 0 0 0 12 4.5h4.5A1.5 1.5 0 0 0 15 3h-1.5Z" clip-rule="evenodd" />
                        <path fill-rule="evenodd" d="M3 9.375C3 8.339 3.84 7.5 4.875 7.5h9.75c1.036 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875h-9.75A1.875 1.875 0 0 1 3 20.625V9.375Zm9.586 4.594a.75.75 0 0 0-1.172-.938l-2.476 3.096-.908-.907a.75.75 0 0 0-1.06 1.06l1.5 1.5a.75.75 0 0 0 1.116-.062l3-3.75Z" clip-rule="evenodd" />
                      </svg>
                                                                 
                    Register
                </a>

                
            </nav>
        </div>
    </header>

    <!-- Your page content goes here -->

</body>
</html>
