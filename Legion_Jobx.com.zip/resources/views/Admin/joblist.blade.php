@extends('Admin.adminpanel')
@section('content')

<h1>Listed Jobs</h1>

<div>
    <div>
        
    </div>
</div>


@endsection