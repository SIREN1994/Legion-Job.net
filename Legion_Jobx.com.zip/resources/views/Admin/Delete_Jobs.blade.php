@extends('Admin.adminpanel')
@section('content')

<h1>This Is Where You Delete The Jobs</h1>

@endsection