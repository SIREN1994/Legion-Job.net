@extends('layout')
@section('content')

<div class="flex items-center justify-center h-screen">
    <div class="bg-white p-8 rounded shadow-md w-96">
        <h2 class="text-2xl font-semibold mb-4">A New Password Has Been Sent To Your Email</h2>
    </div>
</div>

@endsection
